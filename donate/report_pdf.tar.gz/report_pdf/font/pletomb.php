<?php
$type='Type1';
$name='PLETomBold';
$desc=array('Ascent'=>471,'Descent'=>-129,'CapHeight'=>468,'Flags'=>32,'FontBBox'=>'[-503 -301 764 918]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>500);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>500,chr(1)=>500,chr(2)=>500,chr(3)=>500,chr(4)=>500,chr(5)=>500,chr(6)=>500,chr(7)=>500,chr(8)=>500,chr(9)=>500,chr(10)=>500,chr(11)=>500,chr(12)=>500,chr(13)=>500,chr(14)=>500,chr(15)=>500,chr(16)=>500,chr(17)=>500,chr(18)=>500,chr(19)=>500,chr(20)=>500,chr(21)=>500,
	chr(22)=>500,chr(23)=>500,chr(24)=>500,chr(25)=>500,chr(26)=>500,chr(27)=>500,chr(28)=>500,chr(29)=>500,chr(30)=>500,chr(31)=>500,' '=>215,'!'=>190,'"'=>163,'#'=>427,'$'=>358,'%'=>285,'&'=>347,'\''=>115,'('=>190,')'=>214,'*'=>342,'+'=>287,
	','=>131,'-'=>373,'.'=>144,'/'=>362,'0'=>365,'1'=>161,'2'=>353,'3'=>360,'4'=>289,'5'=>354,'6'=>280,'7'=>303,'8'=>268,'9'=>337,':'=>179,';'=>157,'<'=>271,'='=>465,'>'=>276,'?'=>298,'@'=>387,'A'=>423,
	'B'=>485,'C'=>504,'D'=>595,'E'=>401,'F'=>348,'G'=>592,'H'=>366,'I'=>438,'J'=>503,'K'=>354,'L'=>541,'M'=>378,'N'=>477,'O'=>517,'P'=>437,'Q'=>544,'R'=>392,'S'=>463,'T'=>472,'U'=>372,'V'=>442,'W'=>453,
	'X'=>422,'Y'=>291,'Z'=>480,'['=>287,'\\'=>362,']'=>326,'^'=>206,'_'=>314,'`'=>109,'a'=>388,'b'=>361,'c'=>417,'d'=>415,'e'=>291,'f'=>320,'g'=>246,'h'=>311,'i'=>149,'j'=>277,'k'=>229,'l'=>136,'m'=>421,
	'n'=>290,'o'=>290,'p'=>333,'q'=>282,'r'=>258,'s'=>283,'t'=>272,'u'=>315,'v'=>311,'w'=>386,'x'=>249,'y'=>224,'z'=>289,'{'=>165,'|'=>103,'}'=>158,'~'=>273,chr(127)=>500,chr(128)=>500,chr(129)=>500,chr(130)=>500,chr(131)=>500,
	chr(132)=>500,chr(133)=>500,chr(134)=>500,chr(135)=>500,chr(136)=>500,chr(137)=>500,chr(138)=>500,chr(139)=>500,chr(140)=>500,chr(141)=>500,chr(142)=>500,chr(143)=>500,chr(144)=>500,chr(145)=>500,chr(146)=>500,chr(147)=>500,chr(148)=>500,chr(149)=>500,chr(150)=>500,chr(151)=>500,chr(152)=>500,chr(153)=>500,
	chr(154)=>500,chr(155)=>500,chr(156)=>500,chr(157)=>500,chr(158)=>500,chr(159)=>500,chr(160)=>215,chr(161)=>324,chr(162)=>239,chr(163)=>313,chr(164)=>334,chr(165)=>365,chr(166)=>401,chr(167)=>352,chr(168)=>379,chr(169)=>419,chr(170)=>274,chr(171)=>315,chr(172)=>416,chr(173)=>333,chr(174)=>326,chr(175)=>330,
	chr(176)=>317,chr(177)=>428,chr(178)=>566,chr(179)=>451,chr(180)=>389,chr(181)=>403,chr(182)=>337,chr(183)=>398,chr(184)=>281,chr(185)=>337,chr(186)=>368,chr(187)=>359,chr(188)=>416,chr(189)=>414,chr(190)=>468,chr(191)=>454,chr(192)=>331,chr(193)=>420,chr(194)=>345,chr(195)=>233,chr(196)=>264,chr(197)=>350,
	chr(198)=>338,chr(199)=>370,chr(200)=>342,chr(201)=>431,chr(202)=>315,chr(203)=>346,chr(204)=>384,chr(205)=>321,chr(206)=>332,chr(207)=>335,chr(208)=>199,chr(209)=>0,chr(210)=>169,chr(211)=>201,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>79,chr(219)=>500,
	chr(220)=>500,chr(221)=>500,chr(222)=>500,chr(223)=>417,chr(224)=>160,chr(225)=>271,chr(226)=>195,chr(227)=>198,chr(228)=>213,chr(229)=>196,chr(230)=>285,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>2,chr(238)=>24,chr(239)=>270,chr(240)=>383,chr(241)=>381,
	chr(242)=>392,chr(243)=>344,chr(244)=>438,chr(245)=>416,chr(246)=>408,chr(247)=>588,chr(248)=>499,chr(249)=>461,chr(250)=>393,chr(251)=>675,chr(252)=>500,chr(253)=>500,chr(254)=>500,chr(255)=>500);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='pletomb.z';
$size1=6082;
$size2=32515;
?>
